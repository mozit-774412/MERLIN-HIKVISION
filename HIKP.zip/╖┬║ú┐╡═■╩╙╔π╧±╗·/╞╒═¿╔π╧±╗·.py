import os
import cv2
import numpy as np
import datetime
from PIL import Image, ImageDraw, ImageFont
import time

# 字体路径
font_path_chinese = r"./Fonts/MEEN.ttf"

font_size = 16

# 字体
font_chinese = ImageFont.truetype(font_path_chinese, font_size)

cap = cv2.VideoCapture(0)
cv2.namedWindow('Camera Feed', cv2.WINDOW_NORMAL)

# 用于录像相关变量初始化，直接初始化为录像状态
is_recording = True
video_writer = None
video_fourcc = cv2.VideoWriter_fourcc(*'mp4v')  # 设置视频编码格式
video_out_path = os.path.join('录像', f'video_{int(time.time())}.mp4')  # 生成视频输出路径，包含当前时间戳
width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
video_writer = cv2.VideoWriter(video_out_path, video_fourcc, 20.0, (width, height))  # 设置帧率为20.0，可根据实际调整

def draw_texts(image, formatted_time, long_text1, long_text2, long_text3):
    """
    封装绘制文本信息的函数，只使用MECN字体绘制文本
    :param image: 要绘制文本的图像对象
    :param formatted_time: 格式化后的时间文本
    :param long_text1: 第一行长文本内容
    :param long_text2: 第二行长文本内容
    :param long_text3: 第三行长文本内容
    :return: 绘制好文本的图像对象
    """
    draw = ImageDraw.Draw(image)
    # 绘制时间文本
    x_pos = 40
    y_pos = 20
    for char in formatted_time:
        font_to_use = font_chinese
        color_left, color_right = get_adjusted_color(x_pos, y_pos, image, char, draw)
        draw.text((x_pos, y_pos), char, font=font_to_use, fill=color_left)
        bbox = draw.textbbox((x_pos, y_pos), char, font=font_to_use)
        x_pos += bbox[2] - bbox[0]

    # 文本总控制
    asi = 100
    bsi = 50

    # 绘制第一行文本
    bottom_right_x1 = image.width - asi
    bottom_right_y1 = image.height - bsi
    for char in long_text1:
        font_to_use = font_chinese
        color_left, color_right = get_adjusted_color(bottom_right_x1, bottom_right_y1, image, char, draw)
        draw.text((bottom_right_x1, bottom_right_y1), char, font=font_to_use, fill=color_left)
        bbox = draw.textbbox((bottom_right_x1, bottom_right_y1), char, font=font_to_use)
        bottom_right_x1 += bbox[2] - bbox[0]

    # 绘制第二行文本
    bottom_right_x2 = image.width - asi
    bottom_right_y2 = bottom_right_y1 + bsi + 10
    for char in long_text2:
        font_to_use = font_chinese
        color_left, color_right = get_adjusted_color(bottom_right_x2, bottom_right_y2, image, char, draw)
        draw.text((bottom_right_x2, bottom_right_y2), char, font=font_to_use, fill=color_left)
        bbox = draw.textbbox((bottom_right_x2, bottom_right_y2), char, font=font_to_use)
        bottom_right_x2 += bbox[2] - bbox[0]

    # 绘制第三行文本
    bottom_right_x3 = image.width - asi
    bottom_right_y3 = bottom_right_y2 - bsi
    for char in long_text3:
        font_to_use = font_chinese
        color_left, color_right = get_adjusted_color(bottom_right_x3, bottom_right_y3, image, char, draw)
        draw.text((bottom_right_x3, bottom_right_y3), char, font=font_to_use, fill=color_left)
        bbox = draw.textbbox((bottom_right_x3, bottom_right_y3), char, font=font_to_use)
        bottom_right_x3 += bbox[2] - bbox[0]
    return image


def get_adjusted_color(x, y, image, char, draw, sample_area_width=5):
    """
    更准确地获取调整后的颜色，通过对指定区域（左下角和右上角附近）采样取平均亮度来判断
    :param x: 横坐标
    :param y: 纵坐标
    :param image: 图像
    :param char: 当前要处理的字符
    :param draw: 对应的ImageDraw.Draw实例
    :param sample_area_width=5: 采样区域宽度
    :return: 左右两边的调整后的颜色
    """
    left_sum = [0, 0, 0]
    right_sum = [0, 0, 0]
    half_width = sample_area_width // 2
    count = 0
    # 确保采样区域宽度合理，且有像素可采样
    if sample_area_width > 0 and image.width > 0 and image.height > 0:
        font = font_chinese
        # 使用传入的draw实例获取文本包围盒信息
        bbox = draw.textbbox((x, y), char, font=font)
        bbox_width = bbox[2] - bbox[0]
        bbox_height = bbox[3] - bbox[1]
        # 左下角区域采样
        for yi in range(max(0, y + bbox_height - 2), min(y + bbox_height + 1, image.height)):
            for xi in range(max(0, x - half_width), min(x + half_width, image.width)):
                background_color = image.getpixel((xi, yi))
                left_sum[0] += background_color[0]
                left_sum[1] += background_color[1]
                left_sum[2] += background_color[2]
                count += 1
        # 右上角区域采样
        for yi in range(max(0, y - 1), min(y + 2, image.height)):
            for xi in range(max(0, x + bbox_width - half_width), min(x + bbox_width + half_width, image.width)):
                background_color = image.getpixel((xi, yi))
                right_sum[0] += background_color[0]
                right_sum[1] += background_color[1]
                right_sum[2] += background_color[2]
                count += 1
    else:
        # 可以根据实际情况合理返回默认颜色等处理
        return ([0, 0, 0], [0, 0, 1])

    left_avg_color = [int(s / count) for s in left_sum if count > 0]
    right_avg_color = [int(s / count) for s in right_sum if count > 0]

    left_brightness = sum(left_avg_color) / 3
    right_brightness = sum(right_avg_color) / 3

    left_threshold = 50  # 这里直接使用固定阈值，可根据实际情况调整
    right_threshold = 50  # 这里直接使用固定阈值，可根据实际情况调整

    return (
        (255, 255, 255) if left_brightness < left_threshold else (0, 0, 0),
        (255, 255, 255) if right_brightness < right_threshold else (0, 0, 0)
    )


while True:
    ret, frame = cap.read()
    if ret:
        # 先检查窗口是否可见，若不可见则等待一小段时间后再次检查
        while cv2.getWindowProperty('Camera Feed', cv2.WND_PROP_VISIBLE) < 1:
            time.sleep(0.1)
            continue

        pil_image = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))

        # 获取当前时间文本等内容
        formatted_time = datetime.datetime.now().strftime('%Y年%m月%d日 %A %H:%M:%S')
        weekdays = ['星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期日']
        formatted_time = formatted_time.replace('Monday', weekdays[0]).replace('Tuesday', weekdays[1]).replace('Wednesday', weekdays[2]).replace('Thursday', weekdays[3]).replace('Friday', weekdays[4]).replace('Saturday', weekdays[5]).replace('Sunday', weekdays[6])

        long_text1 = "窗外"
        long_text2 = ""
        long_text3 = ""

        # 调用函数绘制文本
        pil_image = draw_texts(pil_image, formatted_time, long_text1,long_text2,long_text3)

        frame = cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)

        if video_writer is not None:
            video_writer.write(frame)

        screen_width, screen_height = cv2.getWindowImageRect('Camera Feed')[2:4]
        # 增加对获取的窗口尺寸合理性判断，如果宽度或高度小于等于0，则设置默认尺寸（这里设置为640x480，可根据实际情况调整）
        if screen_width <= 0 or screen_height <= 0:
            screen_width = 640
            screen_height = 480
        resized_frame = cv2.resize(frame, (screen_width, screen_height), interpolation=cv2.INTER_NEAREST)
        cv2.imshow('Camera Feed', resized_frame)

        key = cv2.waitKey(1)
        if cv2.getWindowProperty('Camera Feed', cv2.WND_PROP_VISIBLE) < 1 or key & 0xFF == ord('q'):
            break
    else:
        break

# 释放录像资源
if video_writer is not None:
    video_writer.release()

cap.release()
cv2.destroyAllWindows()